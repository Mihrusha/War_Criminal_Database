<?php

use App\Controller\Controller;
use App\Models\Pokidky;
use App\View\View;

include_once "vendor\autoload.php";

$controller = new Controller;

$controller->Main();
?>